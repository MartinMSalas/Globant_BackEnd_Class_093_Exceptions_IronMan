public class Console {
}
