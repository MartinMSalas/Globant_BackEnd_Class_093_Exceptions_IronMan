public class SynthesizerIronMan {
}
