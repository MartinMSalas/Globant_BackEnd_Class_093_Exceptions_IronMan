public class Main {
    public static void main(String[] args) {
        Armor a = new Armor();
        //a.moveFeet("walk", 249);
        //a.moveFeet("run", 124);
        a.move("shoot",100);

    }
}
